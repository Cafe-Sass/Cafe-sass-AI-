"""FastAPI router: POST /ai/brand-colors  (cafe logo -> primary / secondary / accent colors).

Usage in the backend's main app:
    from app.api import router as ai_router
    app.include_router(ai_router)

Standalone for testing:  uvicorn app.api:app --reload   (docs at /docs)
"""
from fastapi import APIRouter, File, HTTPException, UploadFile

from .brand_colors import extract_brand_colors

router = APIRouter(prefix="/ai", tags=["ai"])

ALLOWED = {"image/jpeg", "image/png", "image/webp"}
MAX_BYTES = 5 * 1024 * 1024  # 5 MB


# Plain `def` (not async) so FastAPI runs the work in a worker thread.
@router.post("/brand-colors")
def brand_colors(file: UploadFile = File(...)):
    if file.content_type not in ALLOWED:
        raise HTTPException(415, "Upload a JPG, PNG or WEBP image")
    data = file.file.read()
    if len(data) > MAX_BYTES:
        raise HTTPException(413, "File too large (max 5 MB)")
    try:
        return extract_brand_colors(data)
    except ValueError as e:
        raise HTTPException(400, str(e))


# Standalone app for testing
try:
    from fastapi import FastAPI

    app = FastAPI(title="CafeHub Brand Colors")
    app.include_router(router)

    @app.get("/")
    def health():
        return {"status": "ok", "docs": "/docs"}
except Exception:  # pragma: no cover
    pass
