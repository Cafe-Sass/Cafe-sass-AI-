"""Brand-color tests (synthetic logos, no files needed).  Run: python -m tests.test_brand_colors"""
import cv2
import numpy as np

from app.brand_colors import (contrast, extract_brand_colors, hex_to_lch, linear_to_srgb,
                              oklab_to_linear, srgb_to_oklab)

GREEN, ORANGE = (27, 107, 58), (224, 123, 34)


def _png(img):
    return cv2.imencode(".png", img)[1].tobytes()


def logo(bg=None, circle=GREEN, dot=ORANGE, size=300):
    img = np.zeros((size, size, 4), np.uint8)  # transparent
    if bg is not None:
        img[..., :3] = bg[::-1]
        img[..., 3] = 255
    cv2.circle(img, (size // 2, size // 2), 110, (*circle[::-1], 255), -1)
    if dot is not None:
        cv2.circle(img, (size // 2, size // 2), 35, (*dot[::-1], 255), -1)
    return img


def hue_dist(a, b):
    d = abs(a - b) % 360
    return min(d, 360 - d)


def hue_of(hex_color):
    return hex_to_lch(hex_color)[2]


def test_oklab_roundtrip():
    rgb = np.array([[0.1, 0.5, 0.9], [1, 1, 1], [0, 0, 0], [0.7, 0.2, 0.3]])
    back = linear_to_srgb(oklab_to_linear(srgb_to_oklab(rgb)))
    assert np.allclose(rgb, back, atol=1e-6)


def test_transparent_logo_roles():
    r = extract_brand_colors(_png(logo()))
    p, s, a = (r["palette"][k] for k in ("primary", "secondary", "accent"))
    assert p["source"] == "logo" and s["source"] == "logo" and a["source"] == "generated"
    assert hue_dist(hue_of(p["hex"]), hex_to_lch("#1B6B3A")[2]) < 10      # primary = green
    assert hue_dist(hue_of(s["hex"]), hex_to_lch("#E07B22")[2]) < 10      # secondary = orange
    assert hue_dist(hue_of(a["hex"]), hue_of(p["hex"])) >= 40            # accent is distinct
    assert hue_dist(hue_of(a["hex"]), hue_of(s["hex"])) >= 40
    assert p["share"] > s["share"]
    assert not r["needs_review"]
    for role in (p, s, a):
        assert role["contrast"] >= 4.5 and len(role["scale"]) == 11
    assert contrast([0, 0, 0], [1, 1, 1]) > 20


def test_white_background_is_ignored():
    r = extract_brand_colors(_png(logo(bg=(255, 255, 255))))
    assert all(c["hex"].upper() != "#FFFFFF" for c in r["found_in_logo"])
    assert r["palette"]["primary"]["source"] == "logo"


def test_colored_background_is_kept():
    r = extract_brand_colors(_png(logo(bg=GREEN, circle=(240, 200, 60), dot=None)))
    # the green background is part of the brand -> it is the biggest color, so it becomes primary
    assert hue_dist(hue_of(r["palette"]["primary"]["hex"]), hex_to_lch("#1B6B3A")[2]) < 10
    assert hue_dist(hue_of(r["palette"]["secondary"]["hex"]), hex_to_lch("#F0C83C")[2]) < 10


def test_single_color_generates_secondary():
    r = extract_brand_colors(_png(logo(dot=None)))
    assert r["palette"]["secondary"]["source"] == "generated" and "generated_secondary" in r["tags"]


def test_black_and_white_logo_gets_warm_accent():
    r = extract_brand_colors(_png(logo(bg=(255, 255, 255), circle=(20, 20, 20), dot=None)))
    assert "no_brand_color" in r["tags"] and r["needs_review"]
    assert hue_dist(hue_of(r["palette"]["accent"]["hex"]), 70) < 15


def test_warm_coffee_logo_gets_green_accent():
    r = extract_brand_colors(_png(logo(circle=(90, 58, 34), dot=(243, 229, 207))))
    h = hue_of(r["palette"]["accent"]["hex"])
    assert 120 <= h <= 200 and r["palette"]["primary"]["source"] == "logo"


def test_blank_logo_falls_back_to_coffee_palette():
    r = extract_brand_colors(_png(np.full((100, 100, 3), 255, np.uint8)))
    assert r["tags"] == ["no_colors_found"] and r["needs_review"]
    assert r["palette"]["primary"]["source"] == "default"


def test_cafe_extras_and_determinism():
    data = _png(logo())
    r1, r2 = extract_brand_colors(data), extract_brand_colors(data)
    assert r1 == r2
    qr = [int(r1["cafe"]["qr_color"][i:i + 2], 16) / 255 for i in (1, 3, 5)]
    assert contrast(qr, [1, 1, 1]) >= 7
    assert "--brand-primary" in r1["css_variables"]


def test_invalid_file():
    try:
        extract_brand_colors(b"not an image")
        assert False
    except ValueError:
        pass


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn()
            print("ok", name)
    print("all brand-color tests passed")
